#include "stdio.h"

int main()
{
    printf("hello world");
    getchar();
    return 0;
}
